package com.thejavafullstack.Covid19ProfilerSoapConsumer;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Covid19ProfilerSoapConsumerApplicationTests {



}
