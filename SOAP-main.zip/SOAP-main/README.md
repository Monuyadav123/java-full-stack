# SOAP
Projects to demostrate working of SOAP webservices
