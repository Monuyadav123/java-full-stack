package com.thejavafullstack.Covid19ProfilerSoapProducer;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Covid19ProfilerSoapProducerApplicationTests {


}
